import fetch from "node-fetch";

export const mostrarProductos = async (req, res) => {
  try {
    const respuesta = await fetch(process.env.API_URL);
    const productos = await respuesta.json();

    res.render("index.ejs", { productos });
  } catch (error) {
    res.send("Error al cargar los productos");
  }
};
