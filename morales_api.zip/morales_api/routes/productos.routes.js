import { Router } from "express";
import { mostrarProductos } from "../controllers/productos.controller.js";

const router = Router();

router.get("/", mostrarProductos);

export default router;
